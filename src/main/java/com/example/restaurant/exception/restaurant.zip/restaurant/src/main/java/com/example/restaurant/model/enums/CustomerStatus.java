package com.example.restaurant.model.enums;

public enum CustomerStatus {
    PAİD,NOT_PAID
}
